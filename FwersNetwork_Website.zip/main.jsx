import React from "react";
import ReactDOM from "react-dom/client";
import FwersNetworkHome from "./FwersNetworkHome";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <FwersNetworkHome />
  </React.StrictMode>
);