import React from "react";

const roles = [
  { name: "Vip", color: "bg-yellow-400" },
  { name: "Vip+", color: "bg-yellow-500" },
  { name: "Mvip", color: "bg-blue-700" },
  { name: "Mvip+", color: "bg-blue-800" },
  { name: "Sponsor", color: "bg-orange-500" },
];

export default function FwersNetworkHome() {
  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(to bottom right, #111827, #000)", color: "white", padding: "1rem" }}>
      <header style={{ textAlign: "center", marginBottom: "2rem" }}>
        <h1 style={{ fontSize: "2.5rem", fontWeight: "bold" }}>FwersNetwork</h1>
        <p style={{ color: "#ccc" }}>Kurucu: Fwers</p>
      </header>

      <main style={{ maxWidth: "768px", margin: "0 auto" }}>
        <section style={{ backgroundColor: "rgba(255, 255, 255, 0.05)", borderRadius: "1rem", padding: "1.5rem", marginBottom: "1rem" }}>
          <h2 style={{ fontSize: "1.5rem", fontWeight: "600", marginBottom: "1rem" }}>Roller</h2>
          <ul style={{ listStyle: "none", paddingLeft: 0 }}>
            {roles.map((role, index) => (
              <li key={index} style={{ display: "flex", alignItems: "center", marginBottom: "0.5rem" }}>
                <span style={{ width: "1rem", height: "1rem", borderRadius: "9999px", backgroundColor: role.color.replace('bg-', '') }}></span>
                <span style={{ marginLeft: "0.5rem", fontSize: "1.1rem" }}>{role.name}</span>
              </li>
            ))}
          </ul>
        </section>

        <section style={{ backgroundColor: "rgba(255, 255, 255, 0.05)", borderRadius: "1rem", padding: "1.5rem" }}>
          <h2 style={{ fontSize: "1.25rem", fontWeight: "600", marginBottom: "0.5rem" }}>Hakkımızda</h2>
          <p style={{ color: "#ccc" }}>
            FwersNetwork, oyun tutkunları için oluşturulmuş yenilikçi ve topluluk odaklı bir platformdur. Biz, eğlenceyi ve kaliteyi bir araya getirerek oyunculara unutulmaz bir deneyim sunmayı amaçlıyoruz.
          </p>
        </section>
      </main>
    </div>
  );
}